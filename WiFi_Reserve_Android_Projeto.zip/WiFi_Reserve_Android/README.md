# Wi-Fi Reserve — projeto Android nativo

## O que já funciona nesta versão
- Interface Android nativa em tema azul-marinho/ciano.
- Importar arquivos escolhidos pelo usuário para armazenamento privado do app.
- Limite local real de 100 MB para os arquivos salvos.
- Listar e excluir arquivos offline.
- Mostrar estado da conexão e diferenciar Wi-Fi de outra conexão.
- Ativar/pausar o indicador de armazenamento.
- Escolher até 3 apps prioritários e salvar a seleção localmente.

## Limitações importantes
Este app **não cria internet quando está offline**. Os arquivos importados ficam disponíveis sem conexão, mas mensagens novas, feeds e vídeos das redes sociais não serão carregados sem internet. A tela de apps prioritários só guarda preferências; ela não controla os apps de terceiros.

Esta é uma primeira versão nativa local, não uma versão de produção. Ainda não implementa login/cadastro, verificação de conta única, backend, sincronização em nuvem, planos pagos, cobrança ou conectividade de emergência. Para impedir que alguém crie várias contas e repita o teste grátis, será necessário um servidor com autenticação e controle de elegibilidade — não é confiável fazer isso apenas no aparelho.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `WiFi_Reserve_Android` como projeto.
3. Aguarde o Gradle sincronizar e instalar os componentes de Android SDK solicitados.
4. No menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será gerado normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos do projeto: Android Studio recente, JDK 17, Android SDK 35. A primeira sincronização precisa de internet para baixar o plugin Gradle.

## Identidade
Nome: Wi-Fi Reserve
Pacote: com.wifireserve.app
Versão: 1.0.0
