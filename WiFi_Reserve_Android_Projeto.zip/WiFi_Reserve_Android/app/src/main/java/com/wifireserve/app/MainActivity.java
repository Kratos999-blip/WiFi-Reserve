package com.wifireserve.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final long LIMIT = 100L * 1024L * 1024L;
    private static final int PICK_FILE = 421;
    private final int BG = Color.rgb(7, 15, 35);
    private final int PANEL = Color.rgb(15, 29, 59);
    private final int CYAN = Color.rgb(39, 220, 255);
    private final int WHITE = Color.rgb(241, 247, 255);
    private final int MUTED = Color.rgb(151, 172, 207);
    private LinearLayout root, content, nav;
    private TextView storageText, statusText;
    private SharedPreferences prefs;
    private String page = "Início";
    private boolean active;
    private final String[] appNames = {"WhatsApp", "Instagram", "TikTok", "Facebook"};
    private final HashSet<String> priorities = new HashSet<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("wifi_reserve", MODE_PRIVATE);
        active = prefs.getBoolean("active", false);
        priorities.addAll(prefs.getStringSet("priorities", new HashSet<String>()));
        buildShell();
        showPage("Início");
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(20), dp(18), dp(12));
        setContentView(root);
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        TextView brand = text("WI-FI RESERVE", 22, CYAN, true);
        header.addView(brand);
        TextView sub = text("Seu conteúdo salvo, mesmo sem conexão", 12, MUTED, false);
        header.addView(sub);
        root.addView(header);
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(29, 58, 100));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.topMargin = dp(14); lp.bottomMargin = dp(12);
        root.addView(line, lp);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        String[] pages = {"Início", "Conteúdos", "Prioridades", "Conta"};
        for (String p : pages) {
            Button b = button(p, false);
            b.setTextSize(11);
            b.setPadding(dp(4), dp(8), dp(4), dp(8));
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(48), 1));
            b.setOnClickListener(v -> showPage(p));
        }
        root.addView(nav);
    }

    private void showPage(String p) {
        page = p;
        content.removeAllViews();
        if ("Início".equals(p)) homePage();
        else if ("Conteúdos".equals(p)) contentsPage();
        else if ("Prioridades".equals(p)) prioritiesPage();
        else accountPage();
    }

    private void homePage() {
        content.addView(text("PAINEL PRINCIPAL", 12, MUTED, true));
        TextView title = text("Olá! 👋", 27, WHITE, true);
        addGap(content, 8); content.addView(title);
        content.addView(text("Guarde arquivos importantes para consultar offline.", 14, MUTED, false));
        addGap(content, 18);
        LinearLayout card = card();
        card.addView(text("ARMAZENAMENTO LOCAL", 12, MUTED, true));
        storageText = text("", 26, CYAN, true);
        card.addView(storageText);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgress((int)Math.min(100, storedBytes() * 100 / LIMIT));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(8));
        bp.topMargin = dp(12); bp.bottomMargin = dp(8);
        card.addView(bar, bp);
        card.addView(text("Limite gratuito: 100 MB", 12, MUTED, false));
        updateStorageText();
        content.addView(card);
        addGap(content, 14);
        LinearLayout state = card();
        statusText = text("", 15, WHITE, true);
        state.addView(statusText);
        updateNetworkText();
        state.addView(text("O app não cria internet nem recebe mensagens novas sem conexão.", 12, MUTED, false));
        content.addView(state);
        addGap(content, 14);
        Button toggle = button(active ? "Pausar armazenamento" : "Ativar armazenamento", true);
        content.addView(toggle);
        toggle.setOnClickListener(v -> {
            active = !active;
            prefs.edit().putBoolean("active", active).apply();
            showPage("Início");
            Toast.makeText(this, active ? "Armazenamento ativado" : "Armazenamento pausado", Toast.LENGTH_SHORT).show();
        });
        addGap(content, 10);
        Button add = button("＋ Salvar arquivo para uso offline", false);
        content.addView(add);
        add.setOnClickListener(v -> pickFile());
        addGap(content, 12);
        content.addView(text("O que funciona offline?", 16, WHITE, true));
        content.addView(text("Arquivos que você importar para o app. Feeds, vídeos e mensagens de redes sociais não são baixados automaticamente.", 13, MUTED, false));
    }

    private void contentsPage() {
        content.addView(text("MEUS CONTEÚDOS", 20, WHITE, true));
        addGap(content, 6);
        content.addView(text("Arquivos armazenados neste aparelho.", 13, MUTED, false));
        addGap(content, 12);
        File dir = getFilesDir();
        File[] list = dir.listFiles();
        boolean found = false;
        if (list != null) {
            Arrays.sort(list, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));
            for (File f : list) {
                if (!f.isFile() || f.getName().equals("meta.json")) continue;
                found = true;
                LinearLayout row = card();
                row.addView(text(f.getName(), 14, WHITE, true));
                row.addView(text(formatSize(f.length()), 12, MUTED, false));
                Button del = button("Excluir", false);
                row.addView(del);
                del.setOnClickListener(v -> {
                    new android.app.AlertDialog.Builder(this)
                        .setTitle("Excluir arquivo?")
                        .setMessage("O arquivo será removido do armazenamento local.")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Excluir", (d,w) -> { f.delete(); showPage("Conteúdos"); })
                        .show();
                });
                content.addView(row);
                addGap(content, 8);
            }
        }
        if (!found) content.addView(text("Nenhum arquivo salvo ainda. Toque em “Salvar arquivo” no Início para adicionar um.", 14, MUTED, false));
        addGap(content, 10);
        Button add = button("＋ Importar arquivo", true);
        content.addView(add);
        add.setOnClickListener(v -> pickFile());
    }

    private void prioritiesPage() {
        content.addView(text("APPS PRIORITÁRIOS", 20, WHITE, true));
        addGap(content, 6);
        content.addView(text("Escolha até 3 apps para deixar suas preferências organizadas. Isso não controla o tráfego desses apps.", 13, MUTED, false));
        addGap(content, 12);
        for (String name : appNames) {
            CheckBox cb = new CheckBox(this);
            cb.setText(name);
            cb.setTextColor(WHITE);
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(CYAN));
            cb.setTextSize(16);
            cb.setChecked(priorities.contains(name));
            content.addView(cb);
            cb.setOnClickListener(v -> {
                if (cb.isChecked() && !priorities.contains(name) && priorities.size() >= 3) {
                    cb.setChecked(false);
                    Toast.makeText(this, "Você pode escolher no máximo 3 apps.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (cb.isChecked()) priorities.add(name); else priorities.remove(name);
                prefs.edit().putStringSet("priorities", new HashSet<>(priorities)).apply();
            });
        }
        addGap(content, 14);
        LinearLayout note = card();
        note.addView(text("Importante", 15, CYAN, true));
        note.addView(text("O Wi-Fi Reserve não substitui a internet. WhatsApp, Instagram, TikTok e Facebook precisam de conexão para carregar conteúdo novo.", 13, MUTED, false));
        content.addView(note);
    }

    private void accountPage() {
        content.addView(text("CONTA E SEGURANÇA", 20, WHITE, true));
        addGap(content, 12);
        LinearLayout c = card();
        c.addView(text("Protótipo nativo — versão 1.0", 16, WHITE, true));
        addGap(c, 6);
        c.addView(text("Esta versão salva arquivos localmente e aplica o limite de 100 MB no espaço usado dentro do app.", 13, MUTED, false));
        addGap(c, 10);
        c.addView(text("Ainda não há cadastro/login, sincronização na nuvem, cobrança ou verificação de conta única. Esses recursos precisam de um servidor seguro para evitar que a pessoa recrie contas e resgate o teste gratuito várias vezes.", 13, MUTED, false));
        content.addView(c);
        addGap(content, 14);
        Button clear = button("Apagar todos os arquivos salvos", false);
        content.addView(clear);
        clear.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Apagar arquivos?")
            .setMessage("Essa ação não pode ser desfeita.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar", (d,w) -> {
                File[] files = getFilesDir().listFiles();
                if (files != null) for (File f : files) if (f.isFile()) f.delete();
                showPage("Conteúdos");
            }).show());
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = queryName(uri);
        if (name == null || name.trim().isEmpty()) name = "arquivo_" + System.currentTimeMillis();
        name = safeName(name);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Não foi possível ler o arquivo.");
            File dest = new File(getFilesDir(), name);
            if (dest.exists()) dest = new File(getFilesDir(), System.currentTimeMillis() + "_" + name);
            long available = LIMIT - storedBytes();
            long declared = querySize(uri);
            if (declared > available) {
                Toast.makeText(this, "Esse arquivo ultrapassa o espaço restante de 100 MB.", Toast.LENGTH_LONG).show();
                return;
            }
            FileOutputStream out = new FileOutputStream(dest);
            byte[] buffer = new byte[8192];
            long written = 0;
            int n;
            while ((n = in.read(buffer)) != -1) {
                written += n;
                if (written > available) {
                    out.close(); dest.delete();
                    Toast.makeText(this, "Limite de 100 MB atingido. Arquivo não salvo.", Toast.LENGTH_LONG).show();
                    return;
                }
                out.write(buffer, 0, n);
            }
            out.close();
            Toast.makeText(this, "Arquivo salvo para uso offline.", Toast.LENGTH_SHORT).show();
            showPage("Conteúdos");
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao salvar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String queryName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) return c.getString(ix);
            }
        } catch (Exception ignored) {}
        return null;
    }
    private long querySize(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.SIZE);
                if (ix >= 0) return c.getLong(ix);
            }
        } catch (Exception ignored) {}
        return -1;
    }
    private String safeName(String s) { return s.replaceAll("[^a-zA-Z0-9._ -]", "_").replace("/", "_"); }
    private long storedBytes() {
        long total = 0;
        File[] fs = getFilesDir().listFiles();
        if (fs != null) for (File f : fs) if (f.isFile() && !f.getName().equals("meta.json")) total += f.length();
        return total;
    }
    private void updateStorageText() {
        if (storageText != null) storageText.setText(formatSize(storedBytes()) + " / 100 MB");
    }
    private void updateNetworkText() {
        if (statusText == null) return;
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        Network n = cm == null ? null : cm.getActiveNetwork();
        NetworkCapabilities cap = n == null || cm == null ? null : cm.getNetworkCapabilities(n);
        boolean online = cap != null && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        boolean wifi = cap != null && cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        statusText.setText(online ? (wifi ? "● Conectado ao Wi-Fi" : "● Conectado à internet") : "● Sem conexão");
        statusText.setTextColor(online ? CYAN : Color.rgb(255, 178, 87));
    }
    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L*1024L) return String.format(Locale.US, "%.1f KB", bytes/1024.0);
        return String.format(Locale.US, "%.1f MB", bytes/(1024.0*1024.0));
    }
    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackgroundColor(PANEL);
        return l;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(primary ? BG : WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? CYAN : Color.rgb(27, 49, 86)));
        return b;
    }
    private void addGap(LinearLayout l, int h) {
        View v = new View(this);
        l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
